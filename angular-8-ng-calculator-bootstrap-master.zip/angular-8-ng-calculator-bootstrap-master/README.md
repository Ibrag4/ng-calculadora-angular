# angular-8-ng-calculator-bootstrap

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-8-ng-calculator-bootstrap)